[Appearance]
ColorScheme=Breeze
Font=Bitstream Vera Sans Mono,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1,,0,0

[General]
Name=Konsole
Parent=FALLBACK/
SemanticInputClick=true
SemanticUpDown=true

[Interaction Options]
TextEditorCmd=6
TextEditorCmdCustom=code PATH:LINE:COLUMN
UnderlineFilesEnabled=true

[Scrolling]
HistorySize=10000
