## Arch Simple Splash Screen
A simple blue Arch Linux logo for Plasma Splashscreen for KDE 6. [Originaly from KDE 5 Splash Screen](https://store.kde.org/p/1312961)

![Splash Screen Preview](./contents/previews/splash.png)